import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Leaf, BookOpen, Award, Users, MapPin, Calendar, GraduationCap, Trophy } from "lucide-react";

/**
 * Design Philosophy: Natureza Orgânica & Educação Lúdica
 * - Organic elements with educational playfulness
 * - Warm earth tones and nature-inspired colors
 * - Smooth animations and floating cards
 * - Accessible and modern typography
 */

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}\n      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-green-100">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Leaf className="w-6 h-6 text-green-700" />
              <h1 className="text-2xl font-bold text-green-800">Exploradores da Ciência</h1>
            </div>
            <ul className="hidden md:flex gap-6 text-sm font-medium">
              <li><a href="#inicio" className="text-gray-700 hover:text-green-700 transition">Início</a></li>
              <li><a href="#horta" className="text-gray-700 hover:text-green-700 transition">A Horta</a></li>
              <li><a href="#hortalizas" className="text-gray-700 hover:text-green-700 transition">Hortaliças</a></li>
              <li><a href="#diario" className="text-gray-700 hover:text-green-700 transition">Diário</a></li>
              <li><a href="#fecci" className="text-gray-700 hover:text-green-700 transition">FECCI</a></li>
              <li><a href="#professora" className="text-gray-700 hover:text-green-700 transition">Professora</a></li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="inicio" className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663611789275/c3XwLL6sBiWHzQDKbgkhXt/hero-banner-FzNXM7ovabUCDiwrAenRQ5.webp"
            alt="Estudantes no jardim da escola"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative container mx-auto px-4 py-32 text-white">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 font-fredoka">Bem-vindo ao Clube Exploradores da Ciência</h2>
          <p className="text-xl md:text-2xl mb-2 opacity-95">Descobrindo a ciência através da horta didática da Escola Marcílio Dias</p>
          <p className="text-lg mb-8 opacity-90">📍 Itambaracá - Paraná | 📅 Reuniões: Toda terça-feira após o almoço</p>
          <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg">Saiba Mais</Button>
        </div>
      </section>

      {/* Info Cards */}
      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200 hover:shadow-lg transition-shadow">
            <MapPin className="w-8 h-8 text-green-700 mb-3" />
            <h3 className="font-bold text-green-900 mb-2">Localização</h3>
            <p className="text-sm text-green-800">Itambaracá - Paraná<br/>Escola Marcílio Dias</p>
          </Card>
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 hover:shadow-lg transition-shadow">
            <Calendar className="w-8 h-8 text-blue-700 mb-3" />
            <h3 className="font-bold text-blue-900 mb-2">Reuniões</h3>
            <p className="text-sm text-blue-800">Toda Terça-Feira<br/>Após o Almoço</p>
          </Card>
          <Card className="p-6 bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200 hover:shadow-lg transition-shadow">
            <GraduationCap className="w-8 h-8 text-amber-700 mb-3" />
            <h3 className="font-bold text-amber-900 mb-2">Professora</h3>
            <p className="text-sm text-amber-800">Ana Paula Vieira<br/>Criadora do Clube</p>
          </Card>
          <Card className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200 hover:shadow-lg transition-shadow">
            <Trophy className="w-8 h-8 text-yellow-700 mb-3" />
            <h3 className="font-bold text-yellow-900 mb-2">Conquista</h3>
            <p className="text-sm text-yellow-800">FECCI 2024<br/>1º Lugar!</p>
          </Card>
        </div>
      </section>

      {/* A Horta Section */}
      <section id="horta" className="bg-gradient-to-b from-green-50 to-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <Leaf className="w-8 h-8 text-green-700" />
            <h2 className="text-4xl font-bold text-green-900">A Horta Didática</h2>
          </div>
          <p className="text-gray-600 mb-8 text-lg">Um espaço vivo de aprendizagem e descoberta científica</p>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <p className="text-gray-700 mb-4 leading-relaxed">
                A horta do Clube Exploradores da Ciência fica localizada no quintal da Escola Marcílio Dias, próxima ao laboratório de ciências. É um espaço onde os alunos do clube participam ativamente da criação e manutenção da horta, aprendendo na prática sobre agricultura, biodiversidade e sustentabilidade.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Este é um importante espaço de aprendizagem, onde teoria e prática caminham juntas, permitindo que os estudantes entendam os processos naturais e desenvolvam uma conexão mais profunda com a natureza.
              </p>

              <h3 className="text-2xl font-bold text-green-800 mb-4">🎯 Objetivos da Horta:</h3>
              <div className="space-y-3">
                <div className="flex gap-3 items-start">
                  <span className="text-2xl">🌱</span>
                  <div>
                    <h4 className="font-bold text-green-900">Contato com a Natureza</h4>
                    <p className="text-sm text-gray-600">Promover o contato direto e prático com o mundo natural</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <span className="text-2xl">♻️</span>
                  <div>
                    <h4 className="font-bold text-green-900">Sustentabilidade</h4>
                    <p className="text-sm text-gray-600">Ensinar práticas de agricultura sustentável e ecológica</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <span className="text-2xl">🌍</span>
                  <div>
                    <h4 className="font-bold text-green-900">Responsabilidade Ambiental</h4>
                    <p className="text-sm text-gray-600">Desenvolver consciência e responsabilidade com o meio ambiente</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <span className="text-2xl">🔬</span>
                  <div>
                    <h4 className="font-bold text-green-900">Integração Científica</h4>
                    <p className="text-sm text-gray-600">Integrar conhecimentos de ciências na prática experimental</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663611789275/c3XwLL6sBiWHzQDKbgkhXt/horta-canteiros-XVejKBKvX4BB2m7XAgSgqY.webp"
                alt="Canteiro da horta com cebolas e outras hortaliças"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-300">
              <h3 className="text-xl font-bold text-green-900 mb-3">🍽️ Do Campo para a Mesa</h3>
              <p className="text-green-800">Os alimentos que cultivamos na horta são utilizados na própria escola! Os alunos do clube participam ativamente do cultivo, colheita e preparação das hortaliças, que são posteriormente consumidas na cantina e refeitório da escola.</p>
            </Card>
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-300">
              <h3 className="text-xl font-bold text-blue-900 mb-3">📚 Aprendizagem Integrada</h3>
              <p className="text-blue-800">Este é um importante espaço de aprendizagem, onde teoria e prática caminham juntas, permitindo que os estudantes entendam os processos naturais e desenvolvam uma conexão mais profunda com a natureza e com os princípios científicos fundamentais.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Hortaliças Section */}
      <section id="hortalizas" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <span className="text-4xl">🥬</span>
            <h2 className="text-4xl font-bold text-green-900">Hortaliças Cultivadas</h2>
          </div>
          <p className="text-gray-600 mb-12 text-lg">Diversidade de plantas e aprendizados científicos</p>

          <div className="mb-12 rounded-lg overflow-hidden shadow-lg">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663611789275/c3XwLL6sBiWHzQDKbgkhXt/hortalizas-ilustradas-mZ6GMPpgrNwkGYyLp2gyEq.webp"
              alt="Infográfico educativo com hortaliças"
              className="w-full h-auto"
            />
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: "🥬", name: "Alface", ciclo: "30-40 dias", nutrientes: "Vitaminas A, K" },
              { icon: "🥒", name: "Pepino", ciclo: "50-70 dias", nutrientes: "95% água" },
              { icon: "🍅", name: "Tomate", ciclo: "60-80 dias", nutrientes: "Licopeno" },
              { icon: "🌶️", name: "Pimentão", ciclo: "70-90 dias", nutrientes: "Vitamina C" },
              { icon: "🥕", name: "Cenoura", ciclo: "60-80 dias", nutrientes: "Beta-caroteno" },
              { icon: "🧅", name: "Cebola", ciclo: "100-120 dias", nutrientes: "Antioxidantes" },
            ].map((item, idx) => (
              <Card key={idx} className="p-6 hover:shadow-lg transition-shadow border-green-200">
                <div className="text-5xl mb-3">{item.icon}</div>
                <h3 className="text-xl font-bold text-green-900 mb-2">{item.name}</h3>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-600"><span className="font-semibold">Ciclo:</span> {item.ciclo}</p>
                  <p className="text-gray-600"><span className="font-semibold">Nutrientes:</span> {item.nutrientes}</p>
                </div>
              </Card>
            ))}
          </div>

          <Card className="mt-12 p-6 bg-gradient-to-r from-green-50 to-green-100 border-green-300">
            <p className="text-lg text-green-900">🌱 <strong>Mais variedades em desenvolvimento e plantio!</strong></p>
            <p className="text-green-800 mt-2">Estamos continuamente testando novas espécies e técnicas de cultivo sustentável.</p>
          </Card>
        </div>
      </section>

      {/* Diário de Bordo Section */}
      <section id="diario" className="py-16 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <BookOpen className="w-8 h-8 text-blue-700" />
            <h2 className="text-4xl font-bold text-blue-900">Diário de Bordo</h2>
          </div>
          <p className="text-gray-600 mb-12 text-lg">Registro detalhado de todas as atividades e descobertas</p>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-gray-700 mb-4 leading-relaxed">
                O Diário de Bordo é um caderno especial onde registramos todas as atividades do clube. É aqui que documentamos nossas observações, descobertas, desafios e sucessos no cultivo da horta.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Cada reunião e atividade é cuidadosamente anotada, criando um histórico completo do trabalho do Clube Exploradores da Ciência. É um instrumento essencial de aprendizagem e reflexão sobre o desenvolvimento da horta didática e dos processos naturais.
              </p>

              <h3 className="text-2xl font-bold text-blue-800 mb-4">📋 O que Registramos:</h3>
              <div className="space-y-3">
                {[
                  { num: "1", title: "📅 Data e Hora", desc: "Registro preciso de quando as atividades foram realizadas" },
                  { num: "2", title: "👥 Participantes", desc: "Lista de todos os alunos presentes nas atividades" },
                  { num: "3", title: "📝 Descrição Detalhada", desc: "Anotações completas sobre o que foi feito" },
                  { num: "4", title: "🌱 Observações", desc: "Notas sobre o crescimento das plantas" },
                  { num: "5", title: "🐛 Pragas e Doenças", desc: "Identificação de problemas encontrados" },
                  { num: "6", title: "💡 Aprendizados", desc: "Descobertas e conhecimentos adquiridos" },
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-3 items-start">
                    <div className="w-8 h-8 rounded-full bg-blue-200 text-blue-900 font-bold flex items-center justify-center flex-shrink-0">{item.num}</div>
                    <div>
                      <h4 className="font-bold text-blue-900">{item.title}</h4>
                      <p className="text-sm text-gray-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-lg border-2 border-blue-200">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h4 className="font-bold text-blue-900 mb-4">📖 Exemplo de Registro</h4>
                <div className="space-y-3 text-sm text-gray-700">
                  <p><strong>Data:</strong> 15 de maio de 2024</p>
                  <p><strong>Participantes:</strong> 12 alunos presentes</p>
                  <p><strong>Atividade:</strong> Plantio de sementes de tomate em mudas</p>
                  <p><strong>Observações:</strong> Solo bem hidratado, temperatura ideal para germinação</p>
                  <p><strong>Próximas Ações:</strong> Monitorar diariamente a umidade do solo</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FECCI Section */}
      <section id="fecci" className="py-16 bg-gradient-to-r from-yellow-50 via-green-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <Trophy className="w-8 h-8 text-yellow-700" />
            <h2 className="text-4xl font-bold text-green-900">FECCI 2024</h2>
          </div>
          <p className="text-gray-600 mb-12 text-lg">Feira Estadual de Ciência e Cultura Infantil</p>

          <Card className="p-12 bg-gradient-to-br from-yellow-100 to-green-100 border-yellow-300 text-center">
            <div className="text-6xl mb-4">🏆</div>
            <h3 className="text-3xl font-bold text-green-900 mb-2">1º LUGAR!</h3>
            <p className="text-xl text-green-800 mb-4">Nosso projeto foi premiado na FECCI 2024</p>
            <p className="text-gray-700 max-w-2xl mx-auto">
              O Clube Exploradores da Ciência conquistou o primeiro lugar na Feira Estadual de Ciência e Cultura Infantil, reconhecendo o excelente trabalho realizado na horta didática e a dedicação de todos os alunos envolvidos no projeto.
            </p>
          </Card>

          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <Card className="p-6 bg-white border-green-200 hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-3">🎯</div>
              <h4 className="font-bold text-green-900 mb-2">Projeto Inovador</h4>
              <p className="text-sm text-gray-600">Abordagem criativa e científica para educação ambiental</p>
            </Card>
            <Card className="p-6 bg-white border-green-200 hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-3">👥</div>
              <h4 className="font-bold text-green-900 mb-2">Trabalho em Equipe</h4>
              <p className="text-sm text-gray-600">Colaboração e dedicação de todos os participantes</p>
            </Card>
            <Card className="p-6 bg-white border-green-200 hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-3">🌱</div>
              <h4 className="font-bold text-green-900 mb-2">Sustentabilidade</h4>
              <p className="text-sm text-gray-600">Compromisso com a educação ambiental e sustentável</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Professora Section */}
      <section id="professora" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <Users className="w-8 h-8 text-green-700" />
            <h2 className="text-4xl font-bold text-green-900">Professora Criadora</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663611789275/c3XwLL6sBiWHzQDKbgkhXt/professora-section-KYExkps54ssHcF5VWAz43E.webp"
                alt="Professora Ana Paula Vieira no jardim com alunos"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-green-900 mb-4">Ana Paula Vieira</h3>
              <p className="text-lg text-gray-700 mb-4 leading-relaxed">
                A Professora Ana Paula Vieira é a criadora e coordenadora do Clube Exploradores da Ciência. Com paixão pela educação ambiental e ciências naturais, ela desenvolveu este projeto inovador para proporcionar aos alunos uma aprendizagem prática e significativa.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Sua dedicação e criatividade transformaram a horta didática em um espaço de descoberta, onde cada aluno pode desenvolver suas habilidades científicas e sua conexão com a natureza.
              </p>

              <div className="space-y-4">
                <Card className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                  <h4 className="font-bold text-green-900 mb-2">🎓 Formação</h4>
                  <p className="text-sm text-gray-700">Licenciada em Ciências Biológicas com especialização em Educação Ambiental</p>
                </Card>
                <Card className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                  <h4 className="font-bold text-green-900 mb-2">🌱 Missão</h4>
                  <p className="text-sm text-gray-700">Promover educação científica prática e sustentável para todas as crianças</p>
                </Card>
                <Card className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                  <h4 className="font-bold text-green-900 mb-2">💚 Paixão</h4>
                  <p className="text-sm text-gray-700">Conectar os alunos com a natureza e inspirar o próximo geração de cientistas</p>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-green-800 via-green-700 to-blue-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-lg mb-3">Clube Exploradores da Ciência</h4>
              <p className="text-green-100">Descobrindo a natureza e aprendendo ciência na prática.</p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-3">Informações</h4>
              <p className="text-green-100">📍 Escola Marcílio Dias<br/>Itambaracá - Paraná<br/>📅 Terças-feiras após o almoço</p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-3">Contato</h4>
              <p className="text-green-100">Professora Ana Paula Vieira<br/>Coordenadora do Clube</p>
            </div>
          </div>
          <div className="border-t border-green-600 pt-8 text-center text-green-100">
            <p>&copy; 2024 Clube Exploradores da Ciência. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
