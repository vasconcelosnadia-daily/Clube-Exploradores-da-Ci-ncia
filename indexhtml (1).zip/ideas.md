# Ideias de Design - Clube Exploradores da Ciência

## Resposta 1: Natureza Orgânica & Educação Lúdica
**Probabilidade: 0.08**

### Design Movement
Biophilic Design + Educational Playfulness (inspirado em materiais escolares vintage com toque moderno)

### Core Principles
1. **Conexão com a Natureza**: Elementos naturais (folhas, flores, terra) integrados visualmente
2. **Acessibilidade Educacional**: Tipografia clara e hierarquia visual que facilita aprendizado
3. **Dinamismo Controlado**: Movimento suave sem ser frenético, refletindo crescimento natural
4. **Autenticidade Escolar**: Sensação genuína de um projeto educacional real, não corporativo

### Color Philosophy
- **Paleta Principal**: Verde musgo (#4A6741), terra queimada (#8B6F47), azul céu claro (#87CEEB)
- **Acentos**: Amarelo sol (#F4D03F), verde lima (#BFFF00)
- **Raciocínio**: Cores que remetem ao ambiente natural da horta, transmitindo crescimento, sustentabilidade e esperança
- **Emocional**: Conforto, aprendizado, natureza viva

### Layout Paradigm
- **Estrutura Assimétrica**: Seções com imagens grandes à esquerda/direita alternadas
- **Fluxo Vertical Narrativo**: Como um diário, cada seção conta uma parte da história
- **Uso de Espaço Negativo**: Muito ar entre elementos para respirabilidade visual
- **Cards Flutuantes**: Elementos com sombras suaves que parecem flutuar sobre a página

### Signature Elements
1. **Folhas Decorativas**: Pequenas ilustrações de folhas em cantos e divisões
2. **Divisores Orgânicos**: Linhas onduladas (SVG) entre seções ao invés de linhas retas
3. **Badges de Conquista**: Ícones com bordas arredondadas para destaque de informações (FECCI, reuniões, etc.)

### Interaction Philosophy
- Hover suave com mudança de cor e elevação (scale 1.05)
- Cliques que "plantam" pequenas animações (crescimento)
- Scroll reveal: elementos aparecem conforme o usuário desce a página

### Animation
- Folhas caindo suavemente no background (muito sutil, 0.3 opacity)
- Cards que crescem (scale) ao hover
- Números que contam (counter animation) ao entrar em viewport
- Transições de página suaves com fade-in

### Typography System
- **Display**: "Fredoka One" (bold, amigável, educacional)
- **Body**: "Poppins" (legível, moderna, acessível)
- **Hierarquia**: H1 (3rem), H2 (2rem), H3 (1.5rem), Body (1rem)

---

## Resposta 2: Minimalismo Científico & Dados Visuais
**Probabilidade: 0.07**

### Design Movement
Scientific Minimalism + Data Visualization (inspirado em relatórios científicos modernos)

### Core Principles
1. **Clareza Extrema**: Apenas informação essencial, sem decoração
2. **Precisão Visual**: Grid rigoroso, alinhamento perfeito
3. **Foco em Dados**: Gráficos e estatísticas como protagonistas
4. **Elegância Monástica**: Menos é mais, cada elemento tem propósito

### Color Philosophy
- **Paleta Principal**: Cinza escuro (#2C3E50), branco puro (#FFFFFF), azul marinho (#1A3A52)
- **Acentos**: Verde esmeralda (#2ECC71), laranja queimado (#E67E22)
- **Raciocínio**: Cores que transmitem seriedade científica, confiança e inovação
- **Emocional**: Profissionalismo, rigor, conhecimento

### Layout Paradigm
- **Grid Preciso**: 12 colunas, alinhamento perfeito
- **Tipografia como Estrutura**: Títulos grandes definem seções
- **Espaçamento Matemático**: Proporções de ouro (1.618)
- **Dados em Primeiro Plano**: Gráficos e números centralizados

### Signature Elements
1. **Ícones Científicos**: Microscópio, tubo de ensaio, gráficos
2. **Linhas Geométricas**: Divisores com padrões geométricos
3. **Badges Numerados**: Contadores para estatísticas (dias de cultivo, plantas, etc.)

### Interaction Philosophy
- Transições rápidas e precisas (150ms)
- Hover revela informações adicionais (tooltip)
- Cliques que expandem dados (accordion)

### Animation
- Números contando ao entrar em viewport
- Barras de progresso preenchendo
- Linhas desenhando-se (SVG stroke animation)
- Fade-in suave para elementos

### Typography System
- **Display**: "IBM Plex Mono" (científica, precisa)
- **Body**: "IBM Plex Sans" (legível, profissional)
- **Hierarquia**: H1 (2.5rem), H2 (1.8rem), H3 (1.3rem), Body (0.95rem)

---

## Resposta 3: Narrativa Ilustrada & Storytelling Visual
**Probabilidade: 0.06**

### Design Movement
Illustrated Narrative + Children's Book Aesthetic (inspirado em livros infantis educacionais modernos)

### Core Principles
1. **Contação de Histórias**: Cada seção é um capítulo visual
2. **Ilustrações Customizadas**: Arte original em cada seção
3. **Tipografia Expressiva**: Fontes que têm personalidade
4. **Jornada do Explorador**: Sensação de aventura e descoberta

### Color Philosophy
- **Paleta Principal**: Verde vibrante (#2ECC71), azul céu (#3498DB), terra (#D2691E)
- **Acentos**: Rosa coral (#FF6B6B), amarelo ouro (#F39C12)
- **Raciocínio**: Cores vibrantes e alegres que atraem atenção, transmitindo curiosidade e aventura
- **Emocional**: Diversão, descoberta, inclusão, energia

### Layout Paradigm
- **Seções como Capítulos**: Cada seção tem identidade visual própria
- **Ilustrações Grandes**: Arte como protagonista, texto complementar
- **Fluxo Narrativo**: Começo (Bem-vindo), Meio (Horta, Hortaliças), Clímax (FECCI), Fim (Professora)
- **Espaço para Respirar**: Muito ar branco/verde claro entre seções

### Signature Elements
1. **Personagem Mascote**: Um explorador/cientista pequeno que aparece em várias seções
2. **Ilustrações Temáticas**: Arte única para cada tipo de hortaliça
3. **Adesivos Digitais**: Badges com estilo de adesivo (com sombra)

### Interaction Philosophy
- Hover que faz elementos "pular" (bounce)
- Cliques que revelam mais da história (expandir cards)
- Scroll que desencadeia animações de entrada

### Animation
- Elementos entrando com bounce/spring
- Mascote piscando ou acenando
- Folhas girando suavemente
- Transições coloridas entre seções

### Typography System
- **Display**: "Fredoka One" ou "Pacifico" (amigável, lúdica)
- **Body**: "Quicksand" (suave, moderna, legível)
- **Hierarquia**: H1 (3.5rem), H2 (2.5rem), H3 (1.8rem), Body (1rem)

---

## Design Escolhido: Resposta 1 - Natureza Orgânica & Educação Lúdica

Este design foi selecionado porque:
- Combina autenticidade educacional com estética moderna
- Respeita a natureza do projeto (horta real, aprendizado real)
- Oferece flexibilidade para adicionar imagens reais
- Transmite os valores de sustentabilidade e crescimento
- Mantém acessibilidade sem sacrificar beleza
